#include "test_runner.h"
#include "../modular-sorting.h"

#include <vector>

void SimpleTest1() {
    std::vector<int> input{-3, -18, 0, 9, 2, 4, -1};
    ModularSort(input);
    const std::vector<int> expected{0, -1, 2, -3, 4, 9, -18};
    ASSERT_EQUAL(input, expected);
}

void SimpleTest2() {
    std::vector<int> input{3, -3, 0, -1, 1, 4, -4};
    ModularSort(input);
    const std::vector<int> expected{0, -1, 1, 3, -3, 4, -4};
    ASSERT_EQUAL(input, expected);
}

int main() {
    TestRunner tr;
    RUN_TEST(tr, SimpleTest1);
    RUN_TEST(tr, SimpleTest2);  
}
