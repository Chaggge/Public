#ifndef _MODULAR_SORTING_H_
#define _MODULAT_SORTING_H_

#include <vector>

void ModularSort(std::vector<int>& v);

#endif
