#include "modular-sorting.h"
#include <algorithm>
#include <cmath>

using namespace std;

bool module (int i,int j) { return (abs(i)<abs(j)); }

void ModularSort(vector<int>& v){
    sort(v.begin(), v.end(), module);
}