#include "part-of-vector.h"
#include <algorithm>
#include <iterator>

using namespace std;

void PrintVectorPart(const vector<int>& v, ostream& os){
    auto it = find_if(v.begin(), v.end(), [](int a){return a<0;});
    /*for(;it >= v.begin(); --it){
        os << *it;
    }*/
    reverse_copy(v.begin(), it, ostream_iterator<int>(os, " "));
}
