#include "test_runner.h"
#include "../part-of-vector.h"
#include <sstream>

void SimpleTest1() {
   std::ostringstream oss;
   std::vector<int> v{0, 1, 5, -3, -42, 11};
   PrintVectorPart(v, oss);
   ASSERT_EQUAL(oss.str(), "5 1 0");
}

void SimpleTest2() {
   std::ostringstream oss;
   std::vector<int> v{0, 1, 5, 3, 42, 11};
   PrintVectorPart(v, oss);
   ASSERT_EQUAL(oss.str(), "11 42 3 5 1 0");
}

void SimpleTest3() {
   std::ostringstream oss;
   std::vector<int> v{-1, -5, -3, -42, -11};
   PrintVectorPart(v, oss);
   ASSERT_EQUAL(oss.str(), "");
}

int main() {
   TestRunner tr;
   RUN_TEST(tr, SimpleTest1);
   RUN_TEST(tr, SimpleTest2);
   RUN_TEST(tr, SimpleTest3);
}
