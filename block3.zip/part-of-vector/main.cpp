#include "part-of-vector.h"

int main() {
   std::vector<int> v{0, 1, 5, 3, 42, 1};
   PrintVectorPart(v);
   return 0;
}
