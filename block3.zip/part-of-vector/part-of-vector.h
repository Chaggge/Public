#ifndef _PART_OF_VECTOR_H
#define _PART_OF_VECTOR_H

#include <vector>
#include <iostream>

void PrintVectorPart(const std::vector<int>& v, std::ostream& os = std::cout);

#endif
