#include "test_runner.h"
#include "../case-insensitive-sorting.h"

#include <vector>
#include <string>

void TestShortRandom0() {
    std::vector<std::string> input{"XwhnqEM", "Fi", "i83TB", "E", "TH1IcDr3a", "aI6BuYt", "DI", "91o6RLa", "IGoyYGe", "sairC25VV", "zol", "ccAEtw", "jo2qacG", "kG", "906", "6S59Zc2A", "BS6T", "BJx", "XVJW", "RLecbhfeK"};
    CaseInsensitiveSort(input);
    const std::vector<std::string> expected_output{"6S59Zc2A", "906", "91o6RLa", "aI6BuYt", "BJx", "BS6T", "ccAEtw", "DI", "E", "Fi", "i83TB", "IGoyYGe", "jo2qacG", "kG", "RLecbhfeK", "sairC25VV", "TH1IcDr3a", "XVJW", "XwhnqEM", "zol"};
    ASSERT_EQUAL(input, expected_output);
}

void TestShortRandom1() {
    std::vector<std::string> input{"q7LT9CQ", "wZK0", "nGQ8z7B", "7UA5", "xdb9A", "rQpUZ6U", "VDb4", "2CS", "2icKhlL", "iqo", "FOjMuBX7F", "QGZWTMho7", "MeOLS", "UG5EkXDw", "52cGiEv", "du", "IBZkWN1W4", "yQP", "Fp3fD", "DVpl"};
    CaseInsensitiveSort(input);
    const std::vector<std::string> expected_output{"2CS", "2icKhlL", "52cGiEv", "7UA5", "du", "DVpl", "FOjMuBX7F", "Fp3fD", "IBZkWN1W4", "iqo", "MeOLS", "nGQ8z7B", "q7LT9CQ", "QGZWTMho7", "rQpUZ6U", "UG5EkXDw", "VDb4", "wZK0", "xdb9A", "yQP"};
    ASSERT_EQUAL(input, expected_output);
}

void TestShortRandom2() {
    std::vector<std::string> input{"heL1qxFvq", "n4Dp2Qv", "sWxQH", "k", "a2Y", "oIxA7", "UdaE6sbKn", "v", "RgP8", "l", "5", "HZ", "MGkgeEA", "VwZU", "Rtb", "E", "oGTR", "y0", "fnVPm0", "7Y6"};
    CaseInsensitiveSort(input);
    const std::vector<std::string> expected_output{"5", "7Y6", "a2Y", "E", "fnVPm0", "heL1qxFvq", "HZ", "k", "l", "MGkgeEA", "n4Dp2Qv", "oGTR", "oIxA7", "RgP8", "Rtb", "sWxQH", "UdaE6sbKn", "v", "VwZU", "y0"};
    ASSERT_EQUAL(input, expected_output);
}

void TestShortRandom3() {
    std::vector<std::string> input{"pi9M", "3", "QYGnWem2", "j", "cMih", "GuN4T0jn", "dS", "d", "AaQL3o", "aG6k", "MPhS2DbA", "9nO3kxy", "V262M89J", "BwmmznI", "aTUOg", "RvmN", "FSL9xo", "zqbFXdF", "pAW1DDNit", "PsCbkqUj"};
    CaseInsensitiveSort(input);
    const std::vector<std::string> expected_output{"3", "9nO3kxy", "AaQL3o", "aG6k", "aTUOg", "BwmmznI", "cMih", "d", "dS", "FSL9xo", "GuN4T0jn", "j", "MPhS2DbA", "pAW1DDNit", "pi9M", "PsCbkqUj", "QYGnWem2", "RvmN", "V262M89J", "zqbFXdF"};
    ASSERT_EQUAL(input, expected_output);
}

void TestShortRandom4() {
    std::vector<std::string> input{"EHL", "xRDSI", "kl", "E0wpH", "L5Z8TAzaV", "5", "nI3QTuO8", "GtQsrrmR", "zif", "h8", "iUC", "uBfKZQ", "wM5lMg", "DRdH", "P", "sW", "HB", "fFs6h", "iz", "YYJGaefz"};
    CaseInsensitiveSort(input);
    const std::vector<std::string> expected_output{"5", "DRdH", "E0wpH", "EHL", "fFs6h", "GtQsrrmR", "h8", "HB", "iUC", "iz", "kl", "L5Z8TAzaV", "nI3QTuO8", "P", "sW", "uBfKZQ", "wM5lMg", "xRDSI", "YYJGaefz", "zif"};
    ASSERT_EQUAL(input, expected_output);
}

int main() {
    TestRunner tr;    RUN_TEST(tr, TestShortRandom0);
    RUN_TEST(tr, TestShortRandom1);
    RUN_TEST(tr, TestShortRandom2);
    RUN_TEST(tr, TestShortRandom3);
    RUN_TEST(tr, TestShortRandom4);
}
