#include "test_runner.h"
#include "../case-insensitive-sorting.h"

#include <vector>
#include <string>

void TestCaseSingleValue() {
    std::vector<std::string> input{"V"};
    CaseInsensitiveSort(input);
    const std::vector<std::string> expected_output{"V"};
    ASSERT_EQUAL(input, expected_output);
}


void TestCase1() {
    std::vector<std::string> input{"q", "A"};
    CaseInsensitiveSort(input);
    const std::vector<std::string> expected_output{"A", "q"};
    ASSERT_EQUAL(input, expected_output);
}

void TestCase2() {
    std::vector<std::string> input{"a", "C", "b"};
    CaseInsensitiveSort(input);
    const std::vector<std::string> expected_output{"a", "b", "C"};
    ASSERT_EQUAL(input, expected_output);
}

int main() {
    TestRunner tr;
    RUN_TEST(tr, TestCaseSingleValue);
    RUN_TEST(tr, TestCase1);
    RUN_TEST(tr, TestCase2);
}
