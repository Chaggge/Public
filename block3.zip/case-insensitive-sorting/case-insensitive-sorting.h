#ifndef _CASE_INSENSITIVE_SORTING_H_
#define _CASE_INSENSITIVE_SORTING_H_

#include <vector>
#include <string>

void CaseInsensitiveSort(std::vector<std::string>& v);

#endif