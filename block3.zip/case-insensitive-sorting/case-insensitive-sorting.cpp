#include "case-insensitive-sorting.h"
#include <algorithm>
#include<iostream>
using namespace std;

bool low(string a, string b)
{
    auto t = [](char &c){ return (char)tolower(c); };
    transform(a.begin(),a.end(),a.begin(), t);
    transform(b.begin(),b.end(),b.begin(), t);
    return a < b;
}

void CaseInsensitiveSort(vector<string>& v){
    sort(v.begin(),v.end(),low);
}