#include "case-insensitive-sorting.h"
#include <iostream>

using namespace std;

int main() {
    vector<string> v {"YN5m", "p1MD54huRLup", "ADRhW3vu", "Eg", "vMDWG0o6oFG", "RgFs", "1hJ4kbJN", "JqSeMJ", "KRKJMhxsM3h", "wu6", "bSOOWr", "WHXT2XpGrEiB5Y", "dk", "0YRQPWIba", "iuBdq", "sEtf", "pb64W9", "TISk0JmEGD", "oj2j9SU", "fa", "OCNq6X8", "qmpVpODBWhMp6", "uZ9dtVM54aNF", "6Er8pR", "KHtBGgjiEtQr7e", "sZE41mEoW", "pEao3NZtDBqkE5", "k1VVYklIz86aEY", "nQjUCAtx7H9sz", "fE5ClokP", "zB", "Pdjev4g0djP8", "yV30lHE", "WI", "PoPlpglVOvs", "6M", "KlsYHwtV2A", "E7KA", "EggJn", "owfB", "Q2DSDgCJ", "7KFp2", "eu", "TW3aRWjgmmk8", "ebv8Vx", "Dy", "I1lb", "vCMQPDYAcaghuo", "vwEi", "VlTx9aMyn", "oo9b", "606kAI7Dsp", "Q2HKOauUGrbP", "dnEw5P", "Ro9nn", "d9", "Gfiznal3zyim", "trfzJYLJtD", "z2vh9cOEks", "UMTs6ZcYfBVZ", "2pMpUBar", "1wGyYBfYVr", "PuIj54oV8e", "XNB1v", "mo9QRPIjr", "5nKyq1PCSD", "LYdORZ02R", "lEmBN", "DIKFitGS", "jv8THa9rC5IMzy", "d6cVZu1G9gcLiP", "RUZ0vrO96QR5j", "4AhBc4MkwIPruA", "lxR5oVSj3XM", "P5p", "wunqCoAT", "Xsy", "r7", "ADOt2l", "6EZRXlSpsvjY", "Rxz", "Uln7KO", "3I3GRp1g", "rXzOs", "mzDz0GOcA5uv", "96l", "9Dy", "E8amoZ7mu", "11WY", "4xAd9Ee9sqYgmM", "nwOcTXZLop6dR", "gzF", "OapstLoZW", "ixWlHvRwXoV", "6PzY0", "SD4z", "l6c2rYfc4l7Qf", "nm", "RoVdfzdK0Qn5d", "hC"};
    CaseInsensitiveSort(v);
    for(auto x : v){
        cout << x;
    }
    return 0;
}
