#include "split-string.h"
#include <algorithm>
#include <iostream>
#include <iterator>

using namespace std;

vector<string> SplitInWords(const string& s){
    vector<string> words;
    string buf;
    string::const_iterator it, null = s.begin();
    do{
        it = find(null, s.end(), ' ');
        buf.insert(buf.begin(), null, it);
        //cout << buf;
        words.push_back(buf);
        buf.clear();
        null = it + 1;
    }while(it != s.end());
    
    return words;
}