#include "split-string.h"
#include <iostream>

int main() {
    std::string s;
    std::vector<std::string> words;
    getline(std::cin, s);
    //std::cout<<s;
    words = SplitInWords(s);
    for(auto x : words) std::cout << x << " ";
    std::cout << std::endl;
    return 0;
}


