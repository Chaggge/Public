#include "test_runner.h"

#include <vector>
#include <string>

#include "../split-string.h"

void Test1() {
    const std::vector<std::string> expected{"hello"};
    const std::string str("hello");
    ASSERT_EQUAL(SplitInWords(str), expected);
}

void Test2() {
    const std::vector<std::string> expected{"hello", "world"};
    const std::string str("hello world");
    ASSERT_EQUAL(SplitInWords(str), expected);
}

void Test3() {
    const std::vector<std::string> expected{
        "hello", "world", "hello", "tests", "hello", "cpp"};
    const std::string str("hello world hello tests hello cpp");
    ASSERT_EQUAL(SplitInWords(str), expected);
}

void Test4() {
    const std::vector<std::string> expected{
        "Hello", "world", "Hello", "tests", "Hello", "c", "plus", "plus", "a", "b"};
    const std::string str("Hello world Hello tests Hello c plus plus a b");
    ASSERT_EQUAL(SplitInWords(str), expected);
}

int main() {
    TestRunner tr;
    RUN_TEST(tr, Test1);
    RUN_TEST(tr, Test2);
    RUN_TEST(tr, Test3);
    RUN_TEST(tr, Test4);
}
