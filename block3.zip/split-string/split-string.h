#ifndef _SPLIT_STRING_H_
#define _SPLIT_STRING_H_

#include <string>
#include <vector>

std::vector<std::string> SplitInWords(const std::string& s);

#endif 