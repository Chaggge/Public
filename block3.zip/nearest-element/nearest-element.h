#ifndef _NEAREST_ELEMENT_H_
#define _NEAREST_ELEMENT_H
#include <set>

std::set<int>::const_iterator FindNearestElement(const std::set<int>& numbers, int border);

#endif
