#include "nearest-element.h"
#include <algorithm>
#include <cmath>
#include <iostream>

using namespace std;

set<int>::const_iterator FindNearestElement(const set<int>& numbers, int border){
    set<int>::const_iterator low, up;
    int a, b = 0;
    up = lower_bound(numbers.begin(), numbers.end(), border);
    //cout<<*up<<endl;
    if(up != numbers.begin()) {
        low = prev(up);
        //cout<<*low<<endl;
        //cout<<border<<endl;
        b = abs(*up - border);
        //cout<<b<<endl;
        a = abs(border - *low);
        //cout<<a<<endl;
        if(b > a || a == b) return low;
        if(a > b) return up;
    }
    else return up;
}