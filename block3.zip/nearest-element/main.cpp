#include "nearest-element.h"
#include <iostream>

int main() {
    const std::set <int> st{2, 5, 6, 7, 10, 12};
    std::set<int>::const_iterator a = FindNearestElement(st,18);
    std::cout<<*a;
    return 0;
}
