#include "permutation.h"
#include <vector>
#include <numeric>
#include <algorithm>
#include <iterator>

using namespace std;

void Permutation(int const& number, ostream& os){
    vector<int> container;
    int i = 0;
    cout << number;
    iota(container.begin(), next(container.begin(), number), number);
    for(auto x : container){
        cout << x << endl;
    }
    reverse(container.begin(), container.end());
    do{
        copy(next(container.begin(), number * i), container.end(), ostream_iterator<int>(os, " "));
        ++i;
    }while(prev_permutation(container.begin(), container.end()));

}