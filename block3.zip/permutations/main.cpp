#include <algorithm>
#include <vector>
#include "permutation.h"

int main() {
    int a;
    std::cin >> a;
    Permutation(a);
    return 0;
}
