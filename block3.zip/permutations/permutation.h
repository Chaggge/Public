#ifndef _PERMUTATION_H_
#define _PERMUTATION_H_
#include <iostream>

void Permutation(int const& number, std::ostream& os = std::cout);

#endif